# Task 14: Pandas Series Basics
Objective: Understand the fundamental one-dimensional data structure in Pandas.
Topics: Series creation, custom indexes, indexing, filtering, arithmetic, statistics, describe(), sales analysis, and missing values.
Top 5 Skills: Pandas; Series Data Manipulation; Data Indexing and Filtering; Statistical Data Analysis; Python Data Analysis.
