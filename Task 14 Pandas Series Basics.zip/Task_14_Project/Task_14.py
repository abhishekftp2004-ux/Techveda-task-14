import pandas as pd
import numpy as np

# Create a Series
students = pd.Series([78,85,92,67,74],
                     index=["Aman","Priya","Rahul","Neha","Karan"])
print(students)

# Indexing
print("Rahul:", students["Rahul"])
print("First:", students.iloc[0])

# Filtering
print("Above 80:\n", students[students > 80])

# Arithmetic
print("Bonus marks:\n", students + 5)

# Statistics
print("Count:", students.count())
print("Mean:", students.mean())
print("Median:", students.median())
print("Minimum:", students.min())
print("Maximum:", students.max())
print("Std:", students.std())
print("\nDescribe:\n", students.describe())

# Sales Series
sales=pd.Series([12000,15000,11000,18000,16000],
                index=["Mon","Tue","Wed","Thu","Fri"])
print("Sales above 14000:\n", sales[sales>14000])

# Missing values
data=pd.Series([10,20,np.nan,40,50])
print("Missing:\n", data.isna())
print("Filled:\n", data.fillna(data.mean()))
